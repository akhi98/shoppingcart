import React from 'react';

function Home(props) {
    return (
       
            <div className="jumbotron">
                <h1 className="display-3">Flipkart</h1>
                <p className="lead">Explore the product world</p>
                <hr className="my-2" />
                <p>Welcome to Flipkart</p>
                <p className="lead">
                    <a className="btn btn-primary btn-lg" href="/register" role="button">Sign Up</a>
                </p>
            </div>
    );
}

export default Home;