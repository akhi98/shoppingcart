import React, { Component } from 'react';
import { connect } from 'react-redux';
import { addToCart } from './actions/cartActions';
import {Link} from 'react-router-dom';

 class CartHome extends Component{
 handleClick = (id)=>{
        this.props.addToCart(id); 
    }

    render(){
        let itemList = this.props.items.map(item=>{
            return(
                <div>
                <div className="card">
                    <Link className="nav-link" to="/">LogOut</Link>
                    <table cellPadding="20">
                   <tr><td><Link to="/mycart">Shop</Link></td>
                    <td><Link to="/cart">My cart</Link></td>
                    <td><Link to="/cart"><i className="material-icons">shopping_cart</i></Link></td></tr> 
                    </table>
                </div>
                <div className="card" key={item.id}>
                        <div className="card-image">
                            <img src={item.img} alt={item.title}/>
                            <span className="card-title">{item.title}</span><br/>
                            <u><span to="/" className="btn-floating halfway-fab waves-effect waves-light red" onClick={()=>{this.handleClick(item.id)}}><i className="material-icons">Add to Cart</i></span></u>
                        </div>

                        <div className="card-content">
                            <p>{item.desc}</p>
                            <p><b>Price: {item.price}$</b></p>
                        </div>
                 </div>
                 </div>

            )
            })

        return(
            <div className="container">
                <h3 className="center">Our items</h3>
                <div className="box">
                    {itemList}
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state)=>{
    return {
      items: state.items
    }
  }
const mapDispatchToProps= (dispatch)=>{
    
    return{
        addToCart: (id)=>{dispatch(addToCart(id))}
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(CartHome)