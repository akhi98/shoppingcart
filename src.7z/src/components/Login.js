import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import {Redirect} from 'react-router-dom';
import { useHistory } from "react-router-dom";

class Login extends Component {
    
    login() {

        var inputUsername= document.getElementById("uName");
        var inputPassword= document.getElementById("password");

        var Username = inputUsername.value;
        var Password = inputPassword.value;
        
        if ((Username == localStorage.getItem('uName')) && (Password == localStorage.getItem('password'))) {
            this.props.history.push('/mycart/');
          // alert(`Login Successfull!`);
             } else {
           alert(`Invalid Username or password!`);
           }


    }

    render() {
        return (
            <div className="jumbotron">
            <h1>Login</h1>
            <hr className="my-2" />
            <form className="form-horizontal">
                <table cellPadding="20"><tr>
                 <div class="form-inline">
                   
                      <td><label for="uName">Username </label> </td>
                      <td><input type="text" name="uName" id="uName" class="form-control" placeholder="" aria-describedby="uNameHelp" /></td>
                    
                     <td><p><small id="uNameHelp" class="text-muted">Please provide your username</small></p></td>
                    </div></tr>
                <tr>
                    <div class="form-inline">
                     <td> <label for="password">Password </label></td>
                      <td><input type="password" name="password" id="password" class="form-control" placeholder="" aria-describedby="passwordHelp" /></td>
      
                      <td><small id="passwordHelp" class="text-muted">Please provide your password</small></td>
                    </div></tr><br/>
                <tr><div className="form-inline">
                    <td><button className="btn btn-primary btn-lg" onClick={this.login.bind(this)}>Login</button></td>
                    
                   <td> New User?  <Link className="nav-link" to="/register">Sign Up</Link></td>
                </div></tr>
                </table>   
            </form>         
    
        </div>
        );
    }
}

export default Login;