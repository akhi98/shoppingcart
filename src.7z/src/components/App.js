import React from 'react';
import {Route} from 'react-router-dom';
import Home from './Home';
import Navbar from './Navbar';
import Login from './Login';
import Register from './Register';
import CartHome from './CartHome';
import Cart from './Cart';

function App(props) {
//    b4-navbar-minimal-ul
    return (
        <div>
            <Navbar/>
            <div className="container my-4">
                <Route path="/"  exact component={Home} />
                <Route path="/login" exact component={Login} />
                <Route path="/register" exact component={Register} />
                <Route path="/mycart"  exact component={CartHome} />
                <Route path="/cart" component={Cart} />
            </div>
        </div>
    );
}

export default App;

