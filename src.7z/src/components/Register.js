import React, { Component } from 'react';
import {Link} from 'react-router-dom';

const pattern=RegExp(/[0-9]/i);
const validPswdRegex = RegExp(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/i);
const validUsrRegex = RegExp(!/[A-Z]{1}/i);
const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
const validateForm = (errors) => {
  let valid = true;
  Object.values(errors).forEach(
    (val) => {val.length > 0 && (valid = false)}
  );
  // Object.values(rest).forEach(
  //   (val) => {val === null && (valid = false)}
  // );
  return valid;
};

class Register extends Component {
constructor(props) {
    super(props);
    this.state = {
      fName: null,
      lName: null, 
      email: null,
      uName: null,
      password: null,
      errors: {
        fName: '',
        lName: '',
        email: '',
        uName: '',
        password: '',
      }
    };
  }

  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;

    switch (name) {
       case 'fName': 
          errors.fName = 
             value === null || value === '' || pattern.test(value)
             ? 'First Name must be provided and should not have any numbers!'
             : '';
         break;
       case 'lName': 
          errors.lName = 
           value.length === 0 || pattern.test(value)
              ? 'Last Name must be provided and should not have any numbers!'
              : '';
        break;
      case 'email': 
        errors.email = 
          validEmailRegex.test(value)
            ? ''
            : 'Email is not valid!';
        break;
      case 'uName': 
        errors.uName = 
          value.length !=8
            ? 'Username must contain 8 characters only!'
            : '';
        break;
      case 'password': 
        errors.password = 
          validPswdRegex.test(value)
            ? ''
            : 'Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters!';
        break;
      default:
        break;
    }

    this.setState({errors, [name]: value});
  }

handleSubmit = (event) => {
    event.preventDefault();
    if(validateForm(this.state.errors)) {
      alert(`Registered Successfully!`);
        localStorage.setItem('document',JSON.stringify(this.state));

     var inputUsername= document.getElementById("uName");
     var inputPassword= document.getElementById("password");
      localStorage.setItem("uName", inputUsername.value);
     localStorage.setItem("password", inputPassword.value);
    console.log(document.getElementById("password"));
      console.info('Valid Form')
    }else{
      alert(`Please provide required details!`);
      console.error('Invalid Form')
    }
  }

  componentDidMount() {
    this.documentData = JSON.parse(localStorage.getItem('document'));
 
    if (localStorage.getItem('document')) {
        this.setState({
            fname: this.documentData.fname,
           lname: this.documentData.lname,
           email: this.documentData.email,
           uname: this.documentData.uname,
           password: this.documentData.password
    })
} else {
    this.setState({
        fname: '',
        lname: '',
        email: '',
        uname: '',
        password: ''
    })
}
}

  render() {
    var style = {
      color: 'red'
    };
    const {errors} = this.state;
    return (
      <div className="jumbotron">
                <h1>New User Registration</h1>
                <hr className="my-2" />
            <form className="form-horizontal" onSubmit={this.handleSubmit} noValidate>
            <table cellPadding="20">
                  <tr>
                     <td>
              <label htmlFor="fName">First Name</label></td>
             <td><input type='text' name='fName' id='fName' onChange={this.handleChange} nonValidate /><br/>
           
             {errors.fName.length > 0 && 
                <span className='error' style={style}>{errors.fName}</span>} </td> 
            </tr>
            <tr>
                     <td>
              <label htmlFor="lName">Last Name</label></td>
             <td><input type='text' name='lName' id='lName' onChange={this.handleChange} nonValidate /><br/> 
             {errors.lName.length > 0 && 
                <span className='error' style={style}>{errors.lName}</span>} </td> 
            </tr>
            <tr>
              <td><label htmlFor="email">Email</label></td>
              <td><input type='email' name='email' id='email' onChange={this.handleChange} noValidate /><br/>
              {errors.email.length > 0 && 
                <span className='error' style={style}>{errors.email}</span>} </td>
            </tr>
            <tr>
                     <td>
              <label htmlFor="uName">Username</label></td>
             <td><input type='text' name='uName' id='uName' onChange={this.handleChange} nonValidate /><br/> 
             {errors.uName.length > 0 && 
                <span className='error' style={style}>{errors.uName}</span>} </td> 
            </tr>
            <tr>
              <td><label htmlFor="password">Password</label></td>
              <td><input type='password' name='password' id='password' onChange={this.handleChange} noValidate /><br/>
              {errors.password.length > 0 && 
                <span className='error' style={style}>{errors.password}</span>} </td>
               
            </tr>
            {/* <div className='info'>
              <small>Password must be eight characters in length.</small>
            </div> */}
             <tr>
                <td> <button className="btn btn-primary btn-xs">Register</button></td>
                </tr> 
            </table>
          </form>
          <Link className="nav-link" to="/login">Login Now</Link>
        </div>
      
    );
  }
}
export default Register;