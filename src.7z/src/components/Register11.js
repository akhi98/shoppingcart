import React, { Component } from 'react';
import {Link} from 'react-router-dom';

const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
const validateForm = (errors) => {
  let valid = true;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (valid = false)
  );
  return valid;
}

class Register extends Component {
    constructor(props){
       super(props);
    this.state = {
      values: {
      fname: '',
      lname: '',
      email: '',
      uname: '',
      password: ''
    },
      errors:{
        fname: [],
        lname: [],
        email: [],
        uname: [],
        password: []
      },
      wasValidated: false
    };
}

 fnameRef = React.createRef();
    lnameRef = React.createRef();
    emailRef = React.createRef();
    unameRef = React.createRef();
    passwordRef = React.createRef();

// handleChange= (event)=> {
//     this.setState({[event.target.name]:event.target.value},this.validate);
// }

update=(event)=>{
  console.log(event);
  const newValues = {
    ...this.state.values,
    [event.target.name]: event.target.value
  };

  this.setState(curState => ({
     ...curState,
     values: newValues
  }),
   this.validate
  );
}


 validate=()=>{
    const errors = {
       fname: [],
       lname: [],
       email: [],
       uname: [],
       password: []
     }
       if(this.fnameRef.current.value === ''){
         errors.fname.push('Your first name is required');
       }
  
       if(this.lnameRef.current.value === ''){
         errors.lname.push('Your last name is required');
       }
  
       if(this.passwordRef.current.value.length >8){
         errors.password.push('Password must be greater than 8 characters');
       }
  
       if(this.emailRef.current.value.length <20){
         errors.email.push('Email must have atleast 20 characters');
       }

       if(this.unameRef.current.value.length <8){
         errors.uname.push('Username should not exceed 8 characters');
       }

       this.setState({
         ...this.state,
         errors: errors,
         wasValidated: true
       });
   }
  
  isValid() {
     const { fname, lname, email, uname, password } = this.state.errors;
     return fname.length === 0 && lname.length === 0 && email.length === 0 && uname.length ===0 && password.length === 0;
   }

    render() {
     // const {errors} = this.state;
        return (
            <div className="jumbotron">
                <h1>New User Registration</h1>
                <hr className="my-2" />
            <form className="form-horizontal" onSubmit={this.handleFormSubmit} noValidate>
                <table cellPadding="20">
                  <tr>
                     <td> <label for="fname">First Name</label> </td>
                     <td> <input type="text" name="fname" id="fname" class="form-control" placeholder="" aria-describedby="fnameHelp" value={this.state.fname} onChange={this.handleChange} noValidate /></td>
                    
                    {/* <td> <p><small id="fnameHelp" class="text-muted">Please provide your firstname</small></p></td> */}
                    <div className="invalid-feedback">
                    {
                       errors.fname.length > 0 && 
                      <span className='error'>{errors.fname}</span>
                    }
                      </div>
                     </tr>
                <tr>
                    <td>  <label for="lname">Last Name </label> </td>
                    <td>  <input type="text" name="lname" id="lname" class="form-control" placeholder="" aria-describedby="lnameHelp" value={this.state.lname} onChange={this.handleChange} noValidate /></td>
                   
                    {/* <td> <small id="lnameHelp" class="text-muted">Please provide your lastname</small></td> */}
                    <div className="invalid-feedback">
                    {errors.lname.length > 0 && 
                <span className='error'>{errors.lname}</span>}
                      </div>
                      </tr>
                  <tr>
                    <td> <label for="email">Email</label></td>
                    <td><input type="text" name="email" id="email" class="form-control" placeholder="" aria-describedby="emailHelp" value={this.state.email} onChange={this.handleChange} noValidate /></td>
                    
                    {/* <td> <p><small id="emailHelp" class="text-muted">Please provide your email id</small></p></td> */}
                    <div className="invalid-feedback">
                    {errors.email.length > 0 && 
                <span className='error'>{errors.email}</span>}
                      </div>
                    </tr>
               <tr>
                    <td> <label for="uname">Username</label></td>
                    <td>  <input type="text" name="uname" id="uname" class="form-control" placeholder="" aria-describedby="unameHelp" value={this.state.uname} onChange={this.handleChange} noValidate /></td>
                   
                    <td>  <small id="unameHelp" class="text-muted">Please provide your username</small></td>
                    <div className="invalid-feedback">
                    {errors.uname.length > 0 && 
                <span className='error'>{errors.uname}</span>}
                      </div>
                    </tr>
                  <tr>
                    <td>  <label for="password">Password</label> </td>
                    <td>  <input type="password" name="password" id="password" class="form-control" placeholder="" aria-describedby="passwordHelp" value={this.state.password} onChange={this.handleChange} noValidate /></td>
                    
                    <td> <p><small id="passwordHelp" class="text-muted">Please provide a password for your account with 8 or more characters</small></p></td>
                    <div className="invalid-feedback">
                    {errors.password.length > 0 && 
                <span className='error'>{errors.password}</span>}
                      </div>
                    </tr>
                    <tr>
                <td> <button className="btn btn-primary btn-lg">Register</button></td>
                </tr> 
                </table>
            </form> <br/>
         
            <Link className="nav-link" to="/login">Login Now</Link>

            </div>
        );
    }
}

export default Register;